﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLDemo
{
    public class Mgr
    {
        private DBConnect dBConnect;
        public Mgr() {
            dBConnect = new DBConnect();
        }

        public void changeConnection()
        {
            dBConnect.changeConnection();
        }

        public string getConnectionStatus()
        {
            return dBConnect.getConnectionStatus();
        }

        public string test()
        {
            //string query = "SELECT * FROM employees LIMIT 2;";
            //dBConnect.rawQuery(query);

            return dBConnect.getEmployees(5);
        }
    }
}
