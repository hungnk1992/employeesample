﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SQLDemo
{
    public partial class Form1 : Form
    {
        private Mgr mgr;

        public Form1()
        {
            InitializeComponent();
            init();
        }

        private void init()
        {
            mgr = new Mgr();
        }

        private void idBtnConnectDB_Click(object sender, EventArgs e)
        {
            mgr.changeConnection();

            string connectionStatus = mgr.getConnectionStatus();

            if (connectionStatus == "Connected")
            {
                idBtnConnectDB.Text = "Disconnect DB";
            }
            else
            {
                idBtnConnectDB.Text = "Connect DB";
            }
        }

        private void idBtnEmployees_Click(object sender, EventArgs e)
        {
            string employees = mgr.test();
            idTextareaEmployees.Text = employees;
        }

        private void idTextareaEmployees_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
