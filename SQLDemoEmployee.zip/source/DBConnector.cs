﻿using MySql.Data.MySqlClient;
using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System.Runtime.Remoting.Messaging;

class DBConnect
{
    private MySqlConnection connection;
    private string server;
    private string database;
    private string uid;
    private string password;

    private bool isConnected;
 
    //Constructor
    public DBConnect()
    {
        Initialize();
    }

    public void changeConnection ()
    {
        if (isConnected)
        {
            CloseConnection();
        } else
        {
            OpenConnection();
        }
    }

    //Initialize values
    private void Initialize()
    {
        server = "localhost";
        database = "classicmodels";
        uid = "root";
        password = "";

        string connectionString;
        connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";

        isConnected = false;

        connection = new MySqlConnection(connectionString);
    }

    //open connection to database
    private void OpenConnection()
    {
        try
        {
            connection.Open();
            isConnected = true;
            Console.WriteLine("[DBConnect] Connected!");
        }
        catch (MySqlException ex)
        {
            //When handling errors, you can your application's response based 
            //on the error number.
            //The two most common error numbers when connecting are as follows:
            //0: Cannot connect to server.
            //1045: Invalid user name and/or password.
            switch (ex.Number)
            {
                case 0:
                    MessageBox.Show("Cannot connect to server.  Contact administrator");
                    break;

                case 1045:
                    MessageBox.Show("Invalid username/password, please try again");
                    break;
            }
        }
    }

    //Close connection
    private void CloseConnection()
    {
        try
        {
            connection.Close();
            isConnected = false;
            Console.WriteLine("[DBConnect] Disconnected!");
        }
        catch (MySqlException ex)
        {
            MessageBox.Show(ex.Message);
        }
    }

    public string getConnectionStatus()
    {
        if (isConnected)
        {
            return "Connected";
        }
        else
        {
            return "Disconnected";
        }
    }

    public void rawQuery(String query)
    {
        try
        {
            MySqlCommand cmd = new MySqlCommand(query, connection);
            MySqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                Console.WriteLine(rdr[0] + " -- " + rdr[1]);
            }
            rdr.Close();
        }
        catch (MySqlException ex)
        {
            Console.WriteLine(ex.Message);
        }
    }

    public string getEmployees (int numEmployees)
    {
        string employees = "";

        try
        {
            MySqlCommand cmd = new MySqlCommand("selectEmployees", connection);

            cmd.CommandType = CommandType.StoredProcedure;

            // 3. add parameter to command, which will be passed to the stored procedure
            cmd.Parameters.Add(new MySqlParameter("@numEmployees", numEmployees));

            MySqlDataReader rdr = cmd.ExecuteReader();
            employees += "No.  | ID          | Name\r\n";
            employees += "------------------------------------\r\n";
            int _counter = 1;
            while (rdr.Read())
            {
                employees += (_counter + "      " + rdr[0] + "       " + rdr[1]) + "\r\n";
                _counter++;
            }

            rdr.Close();
        }
        catch (MySqlException ex)
        {
            Console.WriteLine(ex.Message);
        }

        return employees;
    }

}