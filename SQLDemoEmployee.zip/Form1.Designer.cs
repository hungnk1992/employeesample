﻿namespace SQLDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.idBtnConnectDB = new System.Windows.Forms.Button();
            this.idBtnEmployees = new System.Windows.Forms.Button();
            this.idTextareaEmployees = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // idBtnConnectDB
            // 
            this.idBtnConnectDB.Location = new System.Drawing.Point(13, 13);
            this.idBtnConnectDB.Name = "idBtnConnectDB";
            this.idBtnConnectDB.Size = new System.Drawing.Size(75, 23);
            this.idBtnConnectDB.TabIndex = 0;
            this.idBtnConnectDB.Text = "Connect DB";
            this.idBtnConnectDB.UseVisualStyleBackColor = true;
            this.idBtnConnectDB.Click += new System.EventHandler(this.idBtnConnectDB_Click);
            // 
            // idBtnEmployees
            // 
            this.idBtnEmployees.Location = new System.Drawing.Point(13, 54);
            this.idBtnEmployees.Name = "idBtnEmployees";
            this.idBtnEmployees.Size = new System.Drawing.Size(75, 23);
            this.idBtnEmployees.TabIndex = 1;
            this.idBtnEmployees.Text = "Employees";
            this.idBtnEmployees.UseVisualStyleBackColor = true;
            this.idBtnEmployees.Click += new System.EventHandler(this.idBtnEmployees_Click);
            // 
            // idTextareaEmployees
            // 
            this.idTextareaEmployees.Location = new System.Drawing.Point(13, 95);
            this.idTextareaEmployees.Name = "idTextareaEmployees";
            this.idTextareaEmployees.Size = new System.Drawing.Size(547, 162);
            this.idTextareaEmployees.TabIndex = 2;
            this.idTextareaEmployees.Text = "";
            this.idTextareaEmployees.TextChanged += new System.EventHandler(this.idTextareaEmployees_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 450);
            this.Controls.Add(this.idTextareaEmployees);
            this.Controls.Add(this.idBtnEmployees);
            this.Controls.Add(this.idBtnConnectDB);
            this.Name = "Form1";
            this.Text = "Employees Management";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button idBtnConnectDB;
        private System.Windows.Forms.Button idBtnEmployees;
        private System.Windows.Forms.RichTextBox idTextareaEmployees;
    }
}

